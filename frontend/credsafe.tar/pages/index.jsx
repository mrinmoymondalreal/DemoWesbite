import Display from "@/components/Display";

const index = () => {
  return (
    <>
      <Display/>
    </>
  );
}

export default index;