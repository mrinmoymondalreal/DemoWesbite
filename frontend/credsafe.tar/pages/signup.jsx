import Signup from "@/components/Signup";

const signup = () => {
    return (
        <>
            <Signup/>
        </>
    );
}

export default signup;