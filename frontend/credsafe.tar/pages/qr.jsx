import QR from "@/components/QR";

const qr = () => {
    return (
        <>
            <QR/>
        </>
    );
}

export default qr;