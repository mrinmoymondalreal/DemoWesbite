import Login from "@/components/Login";

const login = () => {
    return (
        <>
            <Login/>
        </>
    );
}

export default login;