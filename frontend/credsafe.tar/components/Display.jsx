
import Login from "./Login";
import Page from "./Page";
import QR from "./QR";
import Signup from "./Signup";

const Display = () => {
    return (
        <>
            <Page/>
        </>
    );
}

export default Display;